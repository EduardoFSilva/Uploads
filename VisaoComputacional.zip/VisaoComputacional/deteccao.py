import cv2
import glob
import os

import imagem

for arquivo in glob.glob(os.path.join("imagens","*.jpg")):
    imagem = cv2.imread(arquivo)
    classificador = cv2.CascadeClassifier("haarcascade_frontalface_default.xml")
    imagemCinza = cv2.cvtColor(imagem, cv2.COLOR_BGR2GRAY)
    facesDetectadas = classificador.detectMultiScale(imagemCinza, scaleFactor=1.2,minNeighbors=5)
    print(facesDetectadas)
    print("Faces Detectadas: ", len(facesDetectadas))

    for(x,y,l,a) in facesDetectadas:
        cv2.rectangle(imagem,(x,y),(x+l,y+a),(101, 12, 235),3)

    cv2.imshow("Detector haar", imagem)
    cv2.waitKey(0)
    cv2.destroyAllWindows()