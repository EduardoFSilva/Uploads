import cv2

img = cv2.imread("diegoide.jpg")
cv2.imshow("DIEGOIDE !!!!",img)
cv2.waitKey(0)
cv2.destroyAllWindows()