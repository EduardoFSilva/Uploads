#importa a openCV
import cv2
import glob
import os


#carregar imagem
#imagem = cv2.imread("desenho4.jpg")

#para abrir imagens de uma pasta
for arquivo in glob.glob( os.path.join( "friends", "*.jpg" ) ):
    imagem = cv2.imread( arquivo )

    #inicio detectar faces

    classificador = cv2.CascadeClassifier("haarcascade_frontalface_default.xml")
    imagemCinza = cv2.cvtColor(imagem, cv2.COLOR_BGR2GRAY)

    #passar parametro scaleFactor (a escala da imagem) para melhorar a precisão do resultado

    #aumenta o tamanho da imagem, qnt menor mais faces tentará encontrar

    #minSize tbm melhora a precisão, pois diminui o tamanho da face

    facesDetectadas = classificador.detectMultiScale(imagemCinza, scaleFactor=1.2, minNeighbors=5)

    # encontra faces e imprime no terminal os valores do bounding box
    print(facesDetectadas)


    #imprime quantas faces foram detectadas
    print("Faces detectadas: ", len(facesDetectadas))

    #coloca a bounding box, percorre a matriz facesDetectadas

    for (x, y, l, a) in facesDetectadas:
        #passa o retangulo na imagem original
         cv2.rectangle(imagem, (x, y), (x + l, y + a), (0, 255, 0), 2)
        #2 é a largura da borda

    cv2.imshow("Detector haar", imagem)
    cv2.waitKey(0)

    cv2.destroyAllWindows()